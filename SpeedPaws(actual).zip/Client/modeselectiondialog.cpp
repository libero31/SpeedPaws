#include "modeselectiondialog.h"
#include "ui_modeselectiondialog.h"

ModeSelectionDialog::ModeSelectionDialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::ModeSelectionDialog)
{
    ui->setupUi(this);

}

ModeSelectionDialog::~ModeSelectionDialog()
{
    delete ui;
}

void ModeSelectionDialog::on_easy_clicked()
{
    emit modeSelected("Easy");
    accept();
}


void ModeSelectionDialog::on_medium_clicked()
{
    emit modeSelected("Medium");
    accept();
}


void ModeSelectionDialog::on_hard_clicked()
{
    emit modeSelected("Hard");
    accept();
}
