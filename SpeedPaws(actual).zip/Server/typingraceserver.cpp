#include "typingraceserver.h"
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QDebug>
#include <QFile>
#include <QTextStream>
#include <QRandomGenerator>

TypingRaceServer::TypingRaceServer(quint16 port, QObject *parent)
    : QObject(parent), m_server(new QWebSocketServer("TypingRaceServer", QWebSocketServer::NonSecureMode, this)) {
    if (m_server->listen(QHostAddress::Any, port)) {
        qDebug() << "Server started on port" << port;
        connect(m_server, &QWebSocketServer::newConnection, this, &TypingRaceServer::onNewConnection);
    } else {
        qDebug() << "Failed to start server:" << m_server->errorString();
    }
}

TypingRaceServer::~TypingRaceServer() {
    m_server->close();
    qDeleteAll(m_clients.keys());
}

QString TypingRaceServer::generateUniqueName(const QString &baseName) {
    QString newName = baseName;
    int counter = 1;

    while (m_clients.values().contains(newName)) {
        newName = QString("%1%2").arg(baseName).arg(counter++);
    }
    qDebug() << "Generated unique name:" << newName;
    return newName;
}

void TypingRaceServer::onNewConnection() {
    QWebSocket *client = m_server->nextPendingConnection();

    connect(client, &QWebSocket::textMessageReceived, this, &TypingRaceServer::onTextMessageReceived);
    connect(client, &QWebSocket::disconnected, this, &TypingRaceServer::onClientDisconnected);

    qDebug() << "New connection from" << client->peerAddress().toString();
}

void TypingRaceServer::onTextMessageReceived(const QString &message) {
    QWebSocket *client = qobject_cast<QWebSocket *>(sender());
    if (client) {
        QJsonDocument doc = QJsonDocument::fromJson(message.toUtf8());
        QJsonObject obj = doc.object();
        QString type = obj["type"].toString();

        if (type == "join") {
            QString playerName = obj["playerName"].toString().trimmed();

            if (playerName.isEmpty()) {
                playerName = QString("Player%1").arg(++m_playerCount);
            } else {
                playerName = generateUniqueName(playerName);
            }

            m_clients[client] = playerName;

            qDebug() << playerName << "joined the game.";
            client->sendTextMessage(QString("Welcome %1").arg(playerName));

            broadcastPlayerList();
            broadcastMessage(QString("%1 joined the game!").arg(playerName));
        }
        else if (type == "challengeRequest") {
            QString opponent = obj["opponent"].toString();
            qDebug() << m_clients[client] << "is sending a challenge request to" << opponent;
            sendChallengeRequest(client, opponent);
        }
        else if (type == "challengeAccepted") {
            QString opponent = obj["opponent"].toString();
            qDebug() << m_clients[client] << "accepted the challenge from" << opponent;
            startRace(client, opponent);
        }
        else if (type == "challengeRejected") {
            QString challenger = obj["opponent"].toString();
            qDebug() << m_clients[client] << "rejected the challenge from in text message recieved" << challenger;
            sendChallengeRejected(client, challenger);
        }
        else if (type == "progressUpdate") {
            qDebug() << m_clients[client] << "sent a progress update";
            broadcastMessage(message);
        }
        else if (type == "raceFinished") {
            QString opponent = obj["opponent"].toString();
            int finalSpeed = obj["finalSpeed"].toInt();
            int finalProgress = obj["finalProgress"].toInt();
            int timeTaken = obj["timeTaken"].toInt();

            qDebug() << m_clients[client] << "finished the race with speed:" << finalSpeed << "progress:" << finalProgress << "time taken:" << timeTaken;
            sendRaceResult(client, opponent, finalSpeed, finalProgress, timeTaken);
        }
    }
}

void TypingRaceServer::broadcastMessage(const QString &message) {
    for (QWebSocket *client : m_clients.keys()) {
        qDebug() << "Broadcasting message to" << m_clients[client];
        client->sendTextMessage(message);
    }
}

void TypingRaceServer::broadcastPlayerList() {
    QJsonObject playerListObj;
    QJsonArray playerArray;

    for (auto player : m_clients.values()) {
        playerArray.append(player);
    }

    playerListObj["type"] = "playerList";
    playerListObj["players"] = playerArray;
    qDebug() << "Broadcasting updated player list:";
    broadcastMessage(QJsonDocument(playerListObj).toJson(QJsonDocument::Compact));
}

void TypingRaceServer::onClientDisconnected() {
    QWebSocket *client = qobject_cast<QWebSocket *>(sender());
    if (client) {
        qDebug() << m_clients[client] << "disconnected";
        m_clients.remove(client);
        client->deleteLater();
        broadcastPlayerList();
    }
}

void TypingRaceServer::sendChallengeRequest(QWebSocket *challenger, const QString &opponentName) {
    for (QWebSocket *client : m_clients.keys()) {
        if (m_clients[client] == opponentName) {
            QJsonObject challengeObj;
            challengeObj["type"] = "challengeRequest";
            challengeObj["challenger"] = m_clients[challenger];
            qDebug() << m_clients[challenger] << "sent challenge request to" << opponentName;
            client->sendTextMessage(QJsonDocument(challengeObj).toJson(QJsonDocument::Compact));
            break;
        }
    }
}

QString TypingRaceServer::getRandomParagraph(const QString &fileName)
{
    QFile file(fileName);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        return "The quick brown fox jumps over the lazy dog.";
    }

    QTextStream in(&file);
    QStringList paragraphs;
    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();
        if (!line.isEmpty()) {
            paragraphs.append(line);
        }
    }

    file.close();

    if (paragraphs.isEmpty()) {
        return "Stars twinkled brightly in the clear night sky, illuminating the world below. Crickets sang a gentle melody, blending with the soft rustle of leaves. The world seemed to pause, basking in the serenity of nightfall.";
    }

    int randomIndex = QRandomGenerator::global()->bounded(paragraphs.size());
    return paragraphs[randomIndex];
}

void TypingRaceServer::startRace(QWebSocket *player1, const QString &opponentName) {
    QString randomParagraph = getRandomParagraph(":/text/paragraphs.txt");

    for (QWebSocket *client : m_clients.keys()) {
        if (m_clients[client] == opponentName) {
            QJsonObject raceObj;
            raceObj["type"] = "raceStart";
            raceObj["paragraph"] = randomParagraph;
            raceObj["timeLimit"] = 60;
            raceObj["opponent"] = m_clients[player1];
            raceObj["challenger"] = opponentName;

            qDebug() << "Starting race between" << m_clients[player1] << "and" << opponentName;

            // Sending to opponent
            client->sendTextMessage(QJsonDocument(raceObj).toJson(QJsonDocument::Compact));

            // Swapping player names for the challenger's view
            raceObj["opponent"] = opponentName;
            raceObj["challenger"] = m_clients[player1];

            // Sending to challenger
            player1->sendTextMessage(QJsonDocument(raceObj).toJson(QJsonDocument::Compact));
            break;
        }
    }
}

void TypingRaceServer::sendRaceResult(QWebSocket *sender, const QString &opponentName, int finalSpeed, int finalProgress, int timeTaken) {
    bool resultSent = false;

    for (QWebSocket *client : m_clients.keys()) {
        qDebug() << "Checking client:" << m_clients[client] << "against opponent:" << opponentName;

        if (m_clients[client] == opponentName) {
            QJsonObject resultObj;
            resultObj["type"] = "raceResult";
            resultObj["opponent"] = m_clients[sender];
            resultObj["finalSpeed"] = finalSpeed;
            resultObj["finalProgress"] = finalProgress;
            resultObj["timeTaken"] = timeTaken;

            client->sendTextMessage(QJsonDocument(resultObj).toJson(QJsonDocument::Compact));
            qDebug() << "Race result sent to:" << opponentName;

            resultSent = true;
            break;
        }
    }

    if (!resultSent) {
        qDebug() << "Failed to send race result. Opponent not found:" << opponentName;
    }
}

void TypingRaceServer::sendChallengeRejected(QWebSocket *opponent, const QString &challengerName) {
    qDebug() << "Attempting to send challenge rejection message.";

    for (QWebSocket *client : m_clients.keys()) {
        if (m_clients[client] == challengerName) {
            qDebug() << "Found challenger:" << m_clients[client] << "for rejection message.";
            qDebug() << "Opponent that rejected the challenge:" << m_clients[opponent];

            QJsonObject rejectionObj;
            rejectionObj["type"] = "challengeRejected";
            rejectionObj["opponent"] = m_clients[opponent];
            rejectionObj["message"] = QString("%1 has rejected your challenge.").arg(m_clients[opponent]);

            qDebug() << "Sending rejection message to:" << m_clients[client];
            client->sendTextMessage(QJsonDocument(rejectionObj).toJson(QJsonDocument::Compact));

            qDebug() << "Challenge rejection message sent to" << m_clients[client];

            break;
        }
    }
}
