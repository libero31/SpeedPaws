#include "mainwindow.h"
#include "typingraceserver.h"
#include <QCoreApplication>
#include <QLoggingCategory>

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    // QLoggingCategory::setFilterRules("*.debug=true");
    TypingRaceServer server(12345); // Server listens on port 12345
    QTextStream out(stdout);
    out << "________SPEEDPAWS SERVER LOGS________";
    return a.exec();
}
