#ifndef TYPINGRACESERVER_H
#define TYPINGRACESERVER_H

#include <QWebSocketServer>
#include <QWebSocket>
#include <QHash>

class TypingRaceServer : public QObject {
    Q_OBJECT
public:
    explicit TypingRaceServer(quint16 port, QObject *parent = nullptr);
    ~TypingRaceServer();

private slots:
    void onNewConnection();
    void onTextMessageReceived(const QString &message);
    void onClientDisconnected();

private:
    QWebSocketServer *m_server;
    QHash<QWebSocket *, QString> m_clients; // Map sockets to player IDs
    int m_playerCount = 0;

    void broadcastMessage(const QString &message);

    void broadcastPlayerList();
    void sendChallengeRequest(QWebSocket *challenger, const QString &opponentName);
    void startRace(QWebSocket *player1, const QString &opponentName);

    QString generateUniqueName(const QString &baseName);
    void sendRaceResult(QWebSocket *sender, const QString &opponentName, int finalSpeed, int finalProgress, int timeTaken);
    QString getRandomParagraph(const QString &fileName);
    void sendChallengeRejected(QWebSocket *opponent, const QString &challengerName);
};

#endif // TYPINGRACESERVER_H
